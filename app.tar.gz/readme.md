O armazenamento local armazena:
```py
"dados": {
    "versão": ...,
    "semana_atual", ...,
    "tema": {
        "cor": ...,
        "fundo": ...
    },
    "comportamento": {
        "segunda": {
            ...: ..., # `False` ou `True`
            ...
        },
        ...
    },
    "backup": [ # Não ultrapassa de 3
        {...},
        ...
    ]
}
```