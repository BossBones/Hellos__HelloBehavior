#==> Bibliotecas <==
import flet as ft

#==> Constântes <== 
COMPORTAMENTOS_EXIGIDOS:list[str] = [
    "Acordei no horário",
    "Tomei banho",
    "Escovei os dentes",
    "Fui para a escola",
    "Cuidei dos meus pertences",
    "Fiz a lição de casa",
    "Ajudei nas tarefas de casa",
    "Esperei a hora certa do celular/TV",
    "Não fiz birras"
]

#==> Widgets <==
class DialogoEditor(ft.AlertDialog):
    '''
    **Dialogo que serve para informar acerca do comportamento de um dia específico**

    `pagina:ft.Page` -> Para o controle da página

    `dia_semana:str` -> O Dia da semana que o dialogo está editando
    '''

    def __init__(self, pagina:ft.Page, dia_semana:str):
        # Váriaveis
        self.pagina:ft.Page = pagina
        self.registros:dict[str, ft.Switch] = {}

        # Iniciando a classe pai
        super().__init__(
            title=ft.Text(f"Como foi a sua {dia_semana}?"),
            content=None,
            actions=[
                ft.TextButton("Fechar", on_click=lambda _:pagina.pop_dialog())
            ]
        )
    
    def gerar_registradores(self, registros_dict:dict[str, bool]) -> None:
        '''
        **Gera os registradores, tanto o conteúdo do dialogo, quando a informação acerca**

        `registros_dict:dict[str, bool]` -> Os registros salvos para importar
        '''

        self.content = ft.Column([], height=350, scroll=ft.ScrollMode.AUTO) # Widgets

        for item in COMPORTAMENTOS_EXIGIDOS:
            switch = ft.Switch(label=item, active_color=ft.Colors.GREEN, inactive_thumb_color=ft.Colors.RED_900, inactive_track_color=ft.Colors.RED, track_outline_color=ft.Colors.SURFACE) # O switch ue o usuário irá mexer

            try: # Tenta colocar o valor no switch, se não der, fica `False` mesmo
                if registros_dict[item] == True:
                    switch.value = True
            except:
                pass

            self.registros[item] = switch # Adicionando o switch aos registros
            self.content.controls.append(switch) # Adicionando o switch ao dialogo, os dois apontam ao mesmo switch
        
    def exportar_registradores(self) -> dict[str, bool]:
        '''
        **Exporta as alterações nos registradores**
        '''

        exportado:dict[str, bool] = {}

        for item in self.registros.keys():
            if self.registros[item].value == True:
                exportado[item] = True
            else: # Se for `False` ou `None`, será `False`
                exportado[item] = False
        
        return exportado

class Linha_DiaSemana(ft.Row):
    '''
    **Linha do dia da semana, clique e altere acerca do comportamento**

    `pagina:ft.Page` -> Para o controle da página
    `dados:dict[str, any]` -> Dados salvos
    `dia_semana:str` -> Dia da semana que a linha representa
    '''

    def __init__(self, pagina:ft.Page, dados:dict[str, any], dia_semana:str):
        # Dialogo que edita os registros
        self.dialogo_editor = DialogoEditor(pagina, dia_semana)
        self.dialogo_editor.gerar_registradores(dados["comportamento"][dia_semana])

        # Widgets
        self.semana = ft.Text(f"Minha ", spans=[
            ft.TextSpan(dia_semana, style=ft.TextStyle(color=dados["tema"]["cor"], weight=ft.FontWeight.BOLD)),
            ft.TextSpan(" (")
        ], size=15)
        self.botao = ft.OutlinedButton("Registrar", on_click=lambda:pagina.show_dialog(self.dialogo_editor))

        # Iniciando classe pai
        super().__init__([
            self.semana,
            self.botao,
            ft.Text(")", size=15) # Fechando os parenteses em torno do botão
        ])