import hashlib
import time

def decodificar(senha:str):
    hash:str = hashlib.md5(senha.encode()).hexdigest()
    for i in range(len(hash)):
        if not str(hash[i]).isnumeric():
            hash = hash[:i] + str(int.from_bytes(hash[i].encode(), byteorder="little"))[0] + hash[i + 1:]
    hash = "1" + hash

    telefone = ""

    telefone += "55"
    telefone += str((int(hash[19]) + int(hash[32]) + int(hash[30]) + int(hash[28]) + int(hash[26]) + int(hash[17]) + int(hash[8]))*2)[0]
    telefone += str(int(hash[26]) + int(hash[25]) + int(hash[12]))[0]

    telefone += str((int(hash[18]) + int(hash[25]) + int(hash[18]) + int(hash[26]) + int(hash[29]) + int(hash[17]) + int(hash[5])) + int(hash[12])*10)[0]
    telefone += str(int(hash[31]) + int(hash[1]) + int(hash[9]) + int(hash[24]) + int(hash[13]) + int(hash[25])*10)[0]
    telefone += hash[27]
    telefone += str((int(hash[26]) + int(hash[4]) + int(hash[22]) + int(hash[1]) + int(hash[13]) + int(hash[11]) + int(hash[6])) + (int(hash[12]) + int(hash[20]))*10)[0]
    telefone += hash[20]
    telefone += str(int(hash[10]) + int(hash[26]) + int(hash[25]) + int(hash[31]) + int(hash[1]))[0]
    telefone += str(int(hash[20])*67)[0]
    telefone += str(int(hash[2])*1992)[0]

    return telefone