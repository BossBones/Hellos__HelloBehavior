#==> Bibliotecas <==
from time import sleep
import flet as ft
import datetime
import widgets
import json

#==> Constantes <==
VERSAO = "v1.0"

#==> Principal <==
def obter_semana() -> str:
    '''
    **Retorna a semana atual**
    '''

    agora = datetime.datetime.now()
    dia_semana = agora.weekday()
    segunda = agora - datetime.timedelta(days=dia_semana)
    segunda_noite = segunda.replace(hour=0, minute=0, second=0, microsecond=0)
    return f"{segunda_noite.day}/{segunda_noite.month:02d}"

def obter_padrao_comportamento() -> dict[str, bool]:
    '''
    Obter valor padrão do comportamento, dicionário, útil quando for o primeiro uso ou zerar tudo
    '''

    saida:dict[str, bool] = {}

    for item in widgets.COMPORTAMENTOS_EXIGIDOS:
        saida[item] = False
    
    return saida

async def main(pagina:ft.Page):
    # Configuração da página
    pagina.theme_mode = ft.ThemeMode.DARK
    pagina.spacing = 20
    pagina.padding = 0

    # Váriaveis
    padrao_comportamento = obter_padrao_comportamento()
    semana_atual:str = obter_semana()
    acesso_dados:ft.SharedPreferences = ft.SharedPreferences() # Acesso aos dados
    semana:dict[str, widgets.Linha_DiaSemana|None] = {
        "segunda": None,
        "terça": None,
        "quarta": None,
        "quinta": None,
        "sexta": None
    }
    dados:dict[str, any] = {
        "versão": VERSAO,
        "semana_atual": obter_semana(),
        "tema": {
            "cor": "blue",
            "fundo": "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExNXJ1NWppZWNmZHpuN256ZzRhZmVnZmxqOWloOWVubXgwZXV3amRhZCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/U3qYN8S0j3bpK/giphy.gif"
        },
        "comportamento": {
            "segunda": padrao_comportamento,
            "terça": padrao_comportamento,
            "quarta": padrao_comportamento,
            "quinta": padrao_comportamento,
            "sexta": padrao_comportamento
        },
        "backup": []
    }
    if await acesso_dados.get("dados") != None:
        dados = json.loads(await acesso_dados.get("dados"))

        if dados["semana_atual"] != semana_atual: # Resetando tudo em uma nova semana
            if len(dados["backup"]) >= 3:
                dados["backup"].pop(0) # Remove o primeiro

            dados["backup"].append(dados["comportamento"]) # Adiciona ao backup a semana atual
            dados["backup"][len(dados["backup"])-1]["semana_relacionada"] = dados["semana_atual"] # Informa qual semana é aquele backup

            dados["semana_atual"] = semana_atual
            dados["comportamento"] = {
                "segunda": padrao_comportamento,
                "terça": padrao_comportamento,
                "quarta": padrao_comportamento,
                "quinta": padrao_comportamento,
                "sexta": padrao_comportamento
            }
    
    # Função salvar
    salve = ft.FilledButton(icon=ft.Icons.SAVE, content=ft.Text("Salvar"))
    async def salvar():
        salve.disabled = True
        salve.content.value = "Carregando"
        pagina.update()

        for item in semana.keys():
            dados["comportamento"][item] = semana[item].dialogo_editor.exportar_registradores()

        await acesso_dados.set("dados", json.dumps(dados, ensure_ascii=False))

        sleep(1)

        salve.disabled = False
        salve.content.value = "Salvar"
        pagina.update()

    # Dias da semana
    salve.on_click = salvar
    tudo:ft.Container = ft.Container(content=ft.Column([
        ft.Row([
            salve,
            ft.Text(f"Semana {semana_atual}", size=20, weight=ft.FontWeight.BOLD)
        ]),
        ft.Divider()
    ]), expand=True)
    pagina.add(
        ft.Container(content=ft.Stack([
            ft.Image(src=dados["tema"]["fundo"], expand=True, repeat=ft.ImageRepeat.NO_REPEAT, fit=ft.BoxFit.COVER, height=pagina.height, width=pagina.width), 
            ft.Container(content=ft.Stack([
                ft.Container(border_radius=20, bgcolor=ft.Colors.SURFACE, opacity=0.8),
                ft.Container(content=tudo, padding=20)
            ]), padding=20)
        ]), expand=True))
    
    for item in ["segunda", "terça", "quarta", "quinta", "sexta"]:
        colocar = widgets.Linha_DiaSemana(pagina, dados, item)
        semana[item] = colocar
        tudo.content.controls.append(colocar)
    pagina.update()

ft.run(main, view=ft.AppView.WEB_BROWSER, port=8000)