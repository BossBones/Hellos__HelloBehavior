#==> Bibliotecas <==
from time import sleep
import urllib.parse
import cryptocode
import flet as ft
import datetime
import widgets
import hashlib
import json

#==> Constantes <==
VERSAO = "v1.0"

#==> Principal <==
def obter_semana() -> str:
    '''
    **Retorna a semana atual**
    '''

    agora = datetime.datetime.now()
    dia_semana = agora.weekday()
    segunda = agora - datetime.timedelta(days=dia_semana)
    segunda_noite = segunda.replace(hour=0, minute=0, second=0, microsecond=0)
    return f"{segunda_noite.day}/{segunda_noite.month:02d}"

def obter_padrao_comportamento() -> dict[str, bool]:
    '''
    Obter valor padrão do comportamento, dicionário, útil quando for o primeiro uso ou zerar tudo
    '''

    saida:dict[str, bool] = {}

    for item in widgets.COMPORTAMENTOS_EXIGIDOS:
        saida[item] = False
    
    return saida

def decodificar(senha:str):
    hash:str = hashlib.md5(senha.encode()).hexdigest()
    for i in range(len(hash)):
        if not str(hash[i]).isnumeric():
            hash = hash[:i] + str(int.from_bytes(hash[i].encode(), byteorder="little"))[0] + hash[i + 1:]
    hash = "1" + hash

    telefone = ""

    telefone += "55"
    telefone += str((int(hash[19]) + int(hash[32]) + int(hash[30]) + int(hash[28]) + int(hash[26]) + int(hash[17]) + int(hash[8]))*2)[0]
    telefone += str(int(hash[26]) + int(hash[25]) + int(hash[12]))[0]

    telefone += str((int(hash[18]) + int(hash[25]) + int(hash[18]) + int(hash[26]) + int(hash[29]) + int(hash[17]) + int(hash[5])) + int(hash[12])*10)[0]
    telefone += str(int(hash[31]) + int(hash[1]) + int(hash[9]) + int(hash[24]) + int(hash[13]) + int(hash[25])*10)[0]
    telefone += hash[27]
    telefone += str((int(hash[26]) + int(hash[4]) + int(hash[22]) + int(hash[1]) + int(hash[13]) + int(hash[11]) + int(hash[6])) + (int(hash[12]) + int(hash[20]))*10)[0]
    telefone += hash[20]
    telefone += str(int(hash[10]) + int(hash[26]) + int(hash[25]) + int(hash[31]) + int(hash[1]))[0]
    telefone += str(int(hash[20])*67)[0]
    telefone += str(int(hash[2])*1992)[0]

    return telefone

async def main(pagina:ft.Page):
    # Configuração da página
    pagina.theme_mode = ft.ThemeMode.DARK
    pagina.spacing = 20
    pagina.padding = 0

    # Váriaveis
    url = ft.UrlLauncher()
    padrao_comportamento = obter_padrao_comportamento()
    semana_atual:str = obter_semana()
    acesso_dados:ft.SharedPreferences = ft.SharedPreferences() # Acesso aos dados
    semana:dict[str, widgets.Linha_DiaSemana|None] = {
        "segunda": None,
        "terça": None,
        "quarta": None,
        "quinta": None,
        "sexta": None
    }
    dados:dict[str, any] = {
        "versão": VERSAO,
        "semana_atual": obter_semana(),
        "tema": {
            "cor": "blue",
            "fundo": "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExNXJ1NWppZWNmZHpuN256ZzRhZmVnZmxqOWloOWVubXgwZXV3amRhZCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/U3qYN8S0j3bpK/giphy.gif"
        },
        "comportamento": {
            "segunda": padrao_comportamento,
            "terça": padrao_comportamento,
            "quarta": padrao_comportamento,
            "quinta": padrao_comportamento,
            "sexta": padrao_comportamento
        },
        "backup": []
    }
    if await acesso_dados.get("dados") != None:
        dados = json.loads(await acesso_dados.get("dados"))

        if dados["semana_atual"] != semana_atual: # Resetando tudo em uma nova semana
            if len(dados["backup"]) >= 3:
                dados["backup"].pop(0) # Remove o primeiro

            dados["backup"].append(dados["comportamento"]) # Adiciona ao backup a semana atual
            dados["backup"][len(dados["backup"])-1]["semana_relacionada"] = dados["semana_atual"] # Informa qual semana é aquele backup

            dados["semana_atual"] = semana_atual
            dados["comportamento"] = {
                "segunda": padrao_comportamento,
                "terça": padrao_comportamento,
                "quarta": padrao_comportamento,
                "quinta": padrao_comportamento,
                "sexta": padrao_comportamento
            }
    
    # Função salvar
    senha = []
    salve = ft.FilledButton(icon=ft.Icons.SAVE, content=ft.Text("Salvar"))
    async def salvar():
        salve.disabled = True
        salve.content.value = "Carregando"
        pagina.update()

        for item in semana.keys():
            dados["comportamento"][item] = semana[item].dialogo_editor.exportar_registradores()

        await acesso_dados.set("dados", json.dumps(dados, ensure_ascii=False))

        sleep(1)

        salve.disabled = False
        salve.content.value = "Salvar"
        pagina.update()
    
    # Função exportar
    stackih:ft.Stack
    async def exportar():
        valor = 0
        expo = {}

        for item in semana.keys():
            expo[item] = semana[item].dialogo_editor.exportar_registradores()
        
        expo_txt = "*Comportamento da Heloísa!!*\n\n"
        for item in expo.keys():
            expo_txt += f"==> {str(item[0:1]).upper() + item[1:len(item)]} <==\n"
            for i in expo[item].keys():
                if expo[item][i] == True:
                    expo_txt += f"🟢 {i}\n"
                    valor += 50
                else:
                    expo_txt += f"🔴 {i}\n"
            expo_txt += "\n"
        expo_txt += f"Ela conseguiu acumular *{(valor/100):.2f} reais!*\n\nComprovante: {cryptocode.encrypt(str(senha), "haoiqeb1209")}"

        await ft.Clipboard().set(expo_txt)

    async def exportacao():
        senha_f = ft.TextField(password=True, keyboard_type=ft.KeyboardType.NUMBER, text_align=ft.TextAlign.CENTER, border=ft.InputBorder.UNDERLINE, focused_border_color="white")

        def fechar():
            stackih.controls.pop()
            stackih.controls.pop()
            senha.clear()
            pagina.update()

        def validar_senha():
            if len(senha) != 1:
                stackih.controls[len(stackih.controls)-1].controls[1].content.controls[0].controls[3].value = "Tente novamente"
                senha_f.value = ""
                pagina.update()
            senha.append(senha_f.value)
            if len(senha) == 2:
                stackih.controls[len(stackih.controls)-1].controls[1].content.controls[0].controls.append(ft.Row([ft.Button("Copiar", on_click=exportar), ft.Button("Fechar", on_click=fechar)], alignment=ft.MainAxisAlignment.CENTER))
                
        senha_f.on_submit = validar_senha

        stackih.controls.append(ft.Container(expand=True, bgcolor="black", opacity=0.8))
        stackih.controls.append(ft.Column([ft.Container(height=50), ft.Container(content=ft.Column([
            ft.Column([
                ft.Container(height=20),
                ft.Icon(icon=ft.Icons.LOCK_OUTLINE_ROUNDED),
                ft.Text("Confirme sua identidade", size=20),
                ft.Text("Insira seu PIN atual", size=15),
                senha_f
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, width=9999)
        ]), bgcolor=ft.Colors.GREY_800, border_radius=20, expand=True)]))

        pagina.update()

    # Dias da semana
    salve.on_click = salvar
    tudo:ft.Container = ft.Container(content=ft.Column([
        ft.Row([
            salve,
            ft.Text(f"Semana {semana_atual}", size=20, weight=ft.FontWeight.BOLD)
        ]),
        ft.Divider()
    ]), expand=True)
    stackih = ft.Stack([
            ft.Image(src=dados["tema"]["fundo"], expand=True, repeat=ft.ImageRepeat.NO_REPEAT, fit=ft.BoxFit.COVER, height=pagina.height, width=pagina.width), 
            ft.Container(content=ft.Stack([
                ft.Container(border_radius=20, bgcolor=ft.Colors.SURFACE, opacity=0.8),
                ft.Container(content=tudo, padding=20)
            ]), padding=20)
    ])
    pagina.add(
        ft.Container(content=stackih, expand=True))
    
    for item in ["segunda", "terça", "quarta", "quinta", "sexta"]:
        colocar = widgets.Linha_DiaSemana(pagina, dados, item)
        semana[item] = colocar
        tudo.content.controls.append(colocar)
    tudo.content.controls.append(
        ft.Divider()
    )
    tudo.content.controls.append(
        ft.FilledButton("Exportar e copiar", on_click=exportacao)
    )
    pagina.update()

ft.run(main, view=ft.AppView.WEB_BROWSER, port=8000)